package org.example.domainmodel.validation;

import org.eclipse.xtext.xbase.validation.XbaseJavaValidator;
 

@SuppressWarnings("restriction")
public class DomainmodelJavaValidator extends XbaseJavaValidator {

//	@Check
//	public void checkGreetingStartsWithCapital(Greeting greeting) {
//		if (!Character.isUpperCase(greeting.getName().charAt(0))) {
//			warning("Name should start with a capital", MyDslPackage.Literals.GREETING__NAME);
//		}
//	}

}
