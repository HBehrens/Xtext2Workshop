package org.example.domainmodel.serializer;

public class DomainmodelSyntacticSequencer extends AbstractDomainmodelSyntacticSequencer {
}
