package org.example.domainmodel.ui.contentassist.antlr.internal; 

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.xtext.parsetree.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ui.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ui.editor.contentassist.antlr.internal.DFA;
import org.example.domainmodel.services.DomainmodelGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalDomainmodelParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'package'", "'{'", "'}'", "'.'", "'import'", "'.*'", "'datatype'", "'entity'", "'extends'", "':'", "'many'"
    };
    public static final int RULE_ID=4;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__21=21;
    public static final int T__20=20;
    public static final int EOF=-1;
    public static final int RULE_SL_COMMENT=8;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__19=19;
    public static final int RULE_STRING=6;
    public static final int T__16=16;
    public static final int T__15=15;
    public static final int T__18=18;
    public static final int T__17=17;
    public static final int T__12=12;
    public static final int T__11=11;
    public static final int T__14=14;
    public static final int T__13=13;
    public static final int RULE_INT=5;
    public static final int RULE_WS=9;

    // delegates
    // delegators


        public InternalDomainmodelParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalDomainmodelParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalDomainmodelParser.tokenNames; }
    public String getGrammarFileName() { return "../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g"; }


     
     	private DomainmodelGrammarAccess grammarAccess;
     	
        public void setGrammarAccess(DomainmodelGrammarAccess grammarAccess) {
        	this.grammarAccess = grammarAccess;
        }
        
        @Override
        protected Grammar getGrammar() {
        	return grammarAccess.getGrammar();
        }
        
        @Override
        protected String getValueForTokenName(String tokenName) {
        	return tokenName;
        }




    // $ANTLR start "entryRuleDomainmodel"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:61:1: entryRuleDomainmodel : ruleDomainmodel EOF ;
    public final void entryRuleDomainmodel() throws RecognitionException {
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:62:1: ( ruleDomainmodel EOF )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:63:1: ruleDomainmodel EOF
            {
             before(grammarAccess.getDomainmodelRule()); 
            pushFollow(FOLLOW_ruleDomainmodel_in_entryRuleDomainmodel61);
            ruleDomainmodel();

            state._fsp--;

             after(grammarAccess.getDomainmodelRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleDomainmodel68); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDomainmodel"


    // $ANTLR start "ruleDomainmodel"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:70:1: ruleDomainmodel : ( ( rule__Domainmodel__ElementsAssignment )* ) ;
    public final void ruleDomainmodel() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:74:2: ( ( ( rule__Domainmodel__ElementsAssignment )* ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:75:1: ( ( rule__Domainmodel__ElementsAssignment )* )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:75:1: ( ( rule__Domainmodel__ElementsAssignment )* )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:76:1: ( rule__Domainmodel__ElementsAssignment )*
            {
             before(grammarAccess.getDomainmodelAccess().getElementsAssignment()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:77:1: ( rule__Domainmodel__ElementsAssignment )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11||LA1_0==15||(LA1_0>=17 && LA1_0<=18)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:77:2: rule__Domainmodel__ElementsAssignment
            	    {
            	    pushFollow(FOLLOW_rule__Domainmodel__ElementsAssignment_in_ruleDomainmodel94);
            	    rule__Domainmodel__ElementsAssignment();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             after(grammarAccess.getDomainmodelAccess().getElementsAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDomainmodel"


    // $ANTLR start "entryRulePackageDeclaration"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:89:1: entryRulePackageDeclaration : rulePackageDeclaration EOF ;
    public final void entryRulePackageDeclaration() throws RecognitionException {
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:90:1: ( rulePackageDeclaration EOF )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:91:1: rulePackageDeclaration EOF
            {
             before(grammarAccess.getPackageDeclarationRule()); 
            pushFollow(FOLLOW_rulePackageDeclaration_in_entryRulePackageDeclaration122);
            rulePackageDeclaration();

            state._fsp--;

             after(grammarAccess.getPackageDeclarationRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRulePackageDeclaration129); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePackageDeclaration"


    // $ANTLR start "rulePackageDeclaration"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:98:1: rulePackageDeclaration : ( ( rule__PackageDeclaration__Group__0 ) ) ;
    public final void rulePackageDeclaration() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:102:2: ( ( ( rule__PackageDeclaration__Group__0 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:103:1: ( ( rule__PackageDeclaration__Group__0 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:103:1: ( ( rule__PackageDeclaration__Group__0 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:104:1: ( rule__PackageDeclaration__Group__0 )
            {
             before(grammarAccess.getPackageDeclarationAccess().getGroup()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:105:1: ( rule__PackageDeclaration__Group__0 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:105:2: rule__PackageDeclaration__Group__0
            {
            pushFollow(FOLLOW_rule__PackageDeclaration__Group__0_in_rulePackageDeclaration155);
            rule__PackageDeclaration__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPackageDeclarationAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePackageDeclaration"


    // $ANTLR start "entryRuleAbstractElement"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:117:1: entryRuleAbstractElement : ruleAbstractElement EOF ;
    public final void entryRuleAbstractElement() throws RecognitionException {
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:118:1: ( ruleAbstractElement EOF )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:119:1: ruleAbstractElement EOF
            {
             before(grammarAccess.getAbstractElementRule()); 
            pushFollow(FOLLOW_ruleAbstractElement_in_entryRuleAbstractElement182);
            ruleAbstractElement();

            state._fsp--;

             after(grammarAccess.getAbstractElementRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAbstractElement189); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAbstractElement"


    // $ANTLR start "ruleAbstractElement"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:126:1: ruleAbstractElement : ( ( rule__AbstractElement__Alternatives ) ) ;
    public final void ruleAbstractElement() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:130:2: ( ( ( rule__AbstractElement__Alternatives ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:131:1: ( ( rule__AbstractElement__Alternatives ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:131:1: ( ( rule__AbstractElement__Alternatives ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:132:1: ( rule__AbstractElement__Alternatives )
            {
             before(grammarAccess.getAbstractElementAccess().getAlternatives()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:133:1: ( rule__AbstractElement__Alternatives )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:133:2: rule__AbstractElement__Alternatives
            {
            pushFollow(FOLLOW_rule__AbstractElement__Alternatives_in_ruleAbstractElement215);
            rule__AbstractElement__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getAbstractElementAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAbstractElement"


    // $ANTLR start "entryRuleQualifiedName"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:145:1: entryRuleQualifiedName : ruleQualifiedName EOF ;
    public final void entryRuleQualifiedName() throws RecognitionException {
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:146:1: ( ruleQualifiedName EOF )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:147:1: ruleQualifiedName EOF
            {
             before(grammarAccess.getQualifiedNameRule()); 
            pushFollow(FOLLOW_ruleQualifiedName_in_entryRuleQualifiedName242);
            ruleQualifiedName();

            state._fsp--;

             after(grammarAccess.getQualifiedNameRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleQualifiedName249); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQualifiedName"


    // $ANTLR start "ruleQualifiedName"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:154:1: ruleQualifiedName : ( ( rule__QualifiedName__Group__0 ) ) ;
    public final void ruleQualifiedName() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:158:2: ( ( ( rule__QualifiedName__Group__0 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:159:1: ( ( rule__QualifiedName__Group__0 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:159:1: ( ( rule__QualifiedName__Group__0 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:160:1: ( rule__QualifiedName__Group__0 )
            {
             before(grammarAccess.getQualifiedNameAccess().getGroup()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:161:1: ( rule__QualifiedName__Group__0 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:161:2: rule__QualifiedName__Group__0
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group__0_in_ruleQualifiedName275);
            rule__QualifiedName__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQualifiedNameAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQualifiedName"


    // $ANTLR start "entryRuleImport"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:173:1: entryRuleImport : ruleImport EOF ;
    public final void entryRuleImport() throws RecognitionException {
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:174:1: ( ruleImport EOF )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:175:1: ruleImport EOF
            {
             before(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_ruleImport_in_entryRuleImport302);
            ruleImport();

            state._fsp--;

             after(grammarAccess.getImportRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleImport309); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:182:1: ruleImport : ( ( rule__Import__Group__0 ) ) ;
    public final void ruleImport() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:186:2: ( ( ( rule__Import__Group__0 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:187:1: ( ( rule__Import__Group__0 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:187:1: ( ( rule__Import__Group__0 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:188:1: ( rule__Import__Group__0 )
            {
             before(grammarAccess.getImportAccess().getGroup()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:189:1: ( rule__Import__Group__0 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:189:2: rule__Import__Group__0
            {
            pushFollow(FOLLOW_rule__Import__Group__0_in_ruleImport335);
            rule__Import__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleQualifiedNameWithWildcard"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:201:1: entryRuleQualifiedNameWithWildcard : ruleQualifiedNameWithWildcard EOF ;
    public final void entryRuleQualifiedNameWithWildcard() throws RecognitionException {
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:202:1: ( ruleQualifiedNameWithWildcard EOF )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:203:1: ruleQualifiedNameWithWildcard EOF
            {
             before(grammarAccess.getQualifiedNameWithWildcardRule()); 
            pushFollow(FOLLOW_ruleQualifiedNameWithWildcard_in_entryRuleQualifiedNameWithWildcard362);
            ruleQualifiedNameWithWildcard();

            state._fsp--;

             after(grammarAccess.getQualifiedNameWithWildcardRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleQualifiedNameWithWildcard369); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQualifiedNameWithWildcard"


    // $ANTLR start "ruleQualifiedNameWithWildcard"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:210:1: ruleQualifiedNameWithWildcard : ( ( rule__QualifiedNameWithWildcard__Group__0 ) ) ;
    public final void ruleQualifiedNameWithWildcard() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:214:2: ( ( ( rule__QualifiedNameWithWildcard__Group__0 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:215:1: ( ( rule__QualifiedNameWithWildcard__Group__0 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:215:1: ( ( rule__QualifiedNameWithWildcard__Group__0 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:216:1: ( rule__QualifiedNameWithWildcard__Group__0 )
            {
             before(grammarAccess.getQualifiedNameWithWildcardAccess().getGroup()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:217:1: ( rule__QualifiedNameWithWildcard__Group__0 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:217:2: rule__QualifiedNameWithWildcard__Group__0
            {
            pushFollow(FOLLOW_rule__QualifiedNameWithWildcard__Group__0_in_ruleQualifiedNameWithWildcard395);
            rule__QualifiedNameWithWildcard__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQualifiedNameWithWildcardAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQualifiedNameWithWildcard"


    // $ANTLR start "entryRuleType"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:229:1: entryRuleType : ruleType EOF ;
    public final void entryRuleType() throws RecognitionException {
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:230:1: ( ruleType EOF )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:231:1: ruleType EOF
            {
             before(grammarAccess.getTypeRule()); 
            pushFollow(FOLLOW_ruleType_in_entryRuleType422);
            ruleType();

            state._fsp--;

             after(grammarAccess.getTypeRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleType429); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleType"


    // $ANTLR start "ruleType"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:238:1: ruleType : ( ( rule__Type__Alternatives ) ) ;
    public final void ruleType() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:242:2: ( ( ( rule__Type__Alternatives ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:243:1: ( ( rule__Type__Alternatives ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:243:1: ( ( rule__Type__Alternatives ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:244:1: ( rule__Type__Alternatives )
            {
             before(grammarAccess.getTypeAccess().getAlternatives()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:245:1: ( rule__Type__Alternatives )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:245:2: rule__Type__Alternatives
            {
            pushFollow(FOLLOW_rule__Type__Alternatives_in_ruleType455);
            rule__Type__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleType"


    // $ANTLR start "entryRuleDataType"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:257:1: entryRuleDataType : ruleDataType EOF ;
    public final void entryRuleDataType() throws RecognitionException {
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:258:1: ( ruleDataType EOF )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:259:1: ruleDataType EOF
            {
             before(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_ruleDataType_in_entryRuleDataType482);
            ruleDataType();

            state._fsp--;

             after(grammarAccess.getDataTypeRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleDataType489); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:266:1: ruleDataType : ( ( rule__DataType__Group__0 ) ) ;
    public final void ruleDataType() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:270:2: ( ( ( rule__DataType__Group__0 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:271:1: ( ( rule__DataType__Group__0 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:271:1: ( ( rule__DataType__Group__0 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:272:1: ( rule__DataType__Group__0 )
            {
             before(grammarAccess.getDataTypeAccess().getGroup()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:273:1: ( rule__DataType__Group__0 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:273:2: rule__DataType__Group__0
            {
            pushFollow(FOLLOW_rule__DataType__Group__0_in_ruleDataType515);
            rule__DataType__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDataTypeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleEntity"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:285:1: entryRuleEntity : ruleEntity EOF ;
    public final void entryRuleEntity() throws RecognitionException {
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:286:1: ( ruleEntity EOF )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:287:1: ruleEntity EOF
            {
             before(grammarAccess.getEntityRule()); 
            pushFollow(FOLLOW_ruleEntity_in_entryRuleEntity542);
            ruleEntity();

            state._fsp--;

             after(grammarAccess.getEntityRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEntity549); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEntity"


    // $ANTLR start "ruleEntity"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:294:1: ruleEntity : ( ( rule__Entity__Group__0 ) ) ;
    public final void ruleEntity() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:298:2: ( ( ( rule__Entity__Group__0 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:299:1: ( ( rule__Entity__Group__0 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:299:1: ( ( rule__Entity__Group__0 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:300:1: ( rule__Entity__Group__0 )
            {
             before(grammarAccess.getEntityAccess().getGroup()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:301:1: ( rule__Entity__Group__0 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:301:2: rule__Entity__Group__0
            {
            pushFollow(FOLLOW_rule__Entity__Group__0_in_ruleEntity575);
            rule__Entity__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEntityAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEntity"


    // $ANTLR start "entryRuleFeature"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:313:1: entryRuleFeature : ruleFeature EOF ;
    public final void entryRuleFeature() throws RecognitionException {
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:314:1: ( ruleFeature EOF )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:315:1: ruleFeature EOF
            {
             before(grammarAccess.getFeatureRule()); 
            pushFollow(FOLLOW_ruleFeature_in_entryRuleFeature602);
            ruleFeature();

            state._fsp--;

             after(grammarAccess.getFeatureRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeature609); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFeature"


    // $ANTLR start "ruleFeature"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:322:1: ruleFeature : ( ( rule__Feature__Group__0 ) ) ;
    public final void ruleFeature() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:326:2: ( ( ( rule__Feature__Group__0 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:327:1: ( ( rule__Feature__Group__0 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:327:1: ( ( rule__Feature__Group__0 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:328:1: ( rule__Feature__Group__0 )
            {
             before(grammarAccess.getFeatureAccess().getGroup()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:329:1: ( rule__Feature__Group__0 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:329:2: rule__Feature__Group__0
            {
            pushFollow(FOLLOW_rule__Feature__Group__0_in_ruleFeature635);
            rule__Feature__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFeatureAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFeature"


    // $ANTLR start "rule__AbstractElement__Alternatives"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:341:1: rule__AbstractElement__Alternatives : ( ( rulePackageDeclaration ) | ( ruleType ) | ( ruleImport ) );
    public final void rule__AbstractElement__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:345:1: ( ( rulePackageDeclaration ) | ( ruleType ) | ( ruleImport ) )
            int alt2=3;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt2=1;
                }
                break;
            case 17:
            case 18:
                {
                alt2=2;
                }
                break;
            case 15:
                {
                alt2=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:346:1: ( rulePackageDeclaration )
                    {
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:346:1: ( rulePackageDeclaration )
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:347:1: rulePackageDeclaration
                    {
                     before(grammarAccess.getAbstractElementAccess().getPackageDeclarationParserRuleCall_0()); 
                    pushFollow(FOLLOW_rulePackageDeclaration_in_rule__AbstractElement__Alternatives671);
                    rulePackageDeclaration();

                    state._fsp--;

                     after(grammarAccess.getAbstractElementAccess().getPackageDeclarationParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:352:6: ( ruleType )
                    {
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:352:6: ( ruleType )
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:353:1: ruleType
                    {
                     before(grammarAccess.getAbstractElementAccess().getTypeParserRuleCall_1()); 
                    pushFollow(FOLLOW_ruleType_in_rule__AbstractElement__Alternatives688);
                    ruleType();

                    state._fsp--;

                     after(grammarAccess.getAbstractElementAccess().getTypeParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:358:6: ( ruleImport )
                    {
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:358:6: ( ruleImport )
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:359:1: ruleImport
                    {
                     before(grammarAccess.getAbstractElementAccess().getImportParserRuleCall_2()); 
                    pushFollow(FOLLOW_ruleImport_in_rule__AbstractElement__Alternatives705);
                    ruleImport();

                    state._fsp--;

                     after(grammarAccess.getAbstractElementAccess().getImportParserRuleCall_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AbstractElement__Alternatives"


    // $ANTLR start "rule__Type__Alternatives"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:369:1: rule__Type__Alternatives : ( ( ruleDataType ) | ( ruleEntity ) );
    public final void rule__Type__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:373:1: ( ( ruleDataType ) | ( ruleEntity ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==17) ) {
                alt3=1;
            }
            else if ( (LA3_0==18) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:374:1: ( ruleDataType )
                    {
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:374:1: ( ruleDataType )
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:375:1: ruleDataType
                    {
                     before(grammarAccess.getTypeAccess().getDataTypeParserRuleCall_0()); 
                    pushFollow(FOLLOW_ruleDataType_in_rule__Type__Alternatives737);
                    ruleDataType();

                    state._fsp--;

                     after(grammarAccess.getTypeAccess().getDataTypeParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:380:6: ( ruleEntity )
                    {
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:380:6: ( ruleEntity )
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:381:1: ruleEntity
                    {
                     before(grammarAccess.getTypeAccess().getEntityParserRuleCall_1()); 
                    pushFollow(FOLLOW_ruleEntity_in_rule__Type__Alternatives754);
                    ruleEntity();

                    state._fsp--;

                     after(grammarAccess.getTypeAccess().getEntityParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__Alternatives"


    // $ANTLR start "rule__PackageDeclaration__Group__0"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:393:1: rule__PackageDeclaration__Group__0 : rule__PackageDeclaration__Group__0__Impl rule__PackageDeclaration__Group__1 ;
    public final void rule__PackageDeclaration__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:397:1: ( rule__PackageDeclaration__Group__0__Impl rule__PackageDeclaration__Group__1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:398:2: rule__PackageDeclaration__Group__0__Impl rule__PackageDeclaration__Group__1
            {
            pushFollow(FOLLOW_rule__PackageDeclaration__Group__0__Impl_in_rule__PackageDeclaration__Group__0784);
            rule__PackageDeclaration__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__PackageDeclaration__Group__1_in_rule__PackageDeclaration__Group__0787);
            rule__PackageDeclaration__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PackageDeclaration__Group__0"


    // $ANTLR start "rule__PackageDeclaration__Group__0__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:405:1: rule__PackageDeclaration__Group__0__Impl : ( 'package' ) ;
    public final void rule__PackageDeclaration__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:409:1: ( ( 'package' ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:410:1: ( 'package' )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:410:1: ( 'package' )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:411:1: 'package'
            {
             before(grammarAccess.getPackageDeclarationAccess().getPackageKeyword_0()); 
            match(input,11,FOLLOW_11_in_rule__PackageDeclaration__Group__0__Impl815); 
             after(grammarAccess.getPackageDeclarationAccess().getPackageKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PackageDeclaration__Group__0__Impl"


    // $ANTLR start "rule__PackageDeclaration__Group__1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:424:1: rule__PackageDeclaration__Group__1 : rule__PackageDeclaration__Group__1__Impl rule__PackageDeclaration__Group__2 ;
    public final void rule__PackageDeclaration__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:428:1: ( rule__PackageDeclaration__Group__1__Impl rule__PackageDeclaration__Group__2 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:429:2: rule__PackageDeclaration__Group__1__Impl rule__PackageDeclaration__Group__2
            {
            pushFollow(FOLLOW_rule__PackageDeclaration__Group__1__Impl_in_rule__PackageDeclaration__Group__1846);
            rule__PackageDeclaration__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__PackageDeclaration__Group__2_in_rule__PackageDeclaration__Group__1849);
            rule__PackageDeclaration__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PackageDeclaration__Group__1"


    // $ANTLR start "rule__PackageDeclaration__Group__1__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:436:1: rule__PackageDeclaration__Group__1__Impl : ( ( rule__PackageDeclaration__NameAssignment_1 ) ) ;
    public final void rule__PackageDeclaration__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:440:1: ( ( ( rule__PackageDeclaration__NameAssignment_1 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:441:1: ( ( rule__PackageDeclaration__NameAssignment_1 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:441:1: ( ( rule__PackageDeclaration__NameAssignment_1 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:442:1: ( rule__PackageDeclaration__NameAssignment_1 )
            {
             before(grammarAccess.getPackageDeclarationAccess().getNameAssignment_1()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:443:1: ( rule__PackageDeclaration__NameAssignment_1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:443:2: rule__PackageDeclaration__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__PackageDeclaration__NameAssignment_1_in_rule__PackageDeclaration__Group__1__Impl876);
            rule__PackageDeclaration__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getPackageDeclarationAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PackageDeclaration__Group__1__Impl"


    // $ANTLR start "rule__PackageDeclaration__Group__2"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:453:1: rule__PackageDeclaration__Group__2 : rule__PackageDeclaration__Group__2__Impl rule__PackageDeclaration__Group__3 ;
    public final void rule__PackageDeclaration__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:457:1: ( rule__PackageDeclaration__Group__2__Impl rule__PackageDeclaration__Group__3 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:458:2: rule__PackageDeclaration__Group__2__Impl rule__PackageDeclaration__Group__3
            {
            pushFollow(FOLLOW_rule__PackageDeclaration__Group__2__Impl_in_rule__PackageDeclaration__Group__2906);
            rule__PackageDeclaration__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__PackageDeclaration__Group__3_in_rule__PackageDeclaration__Group__2909);
            rule__PackageDeclaration__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PackageDeclaration__Group__2"


    // $ANTLR start "rule__PackageDeclaration__Group__2__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:465:1: rule__PackageDeclaration__Group__2__Impl : ( '{' ) ;
    public final void rule__PackageDeclaration__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:469:1: ( ( '{' ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:470:1: ( '{' )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:470:1: ( '{' )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:471:1: '{'
            {
             before(grammarAccess.getPackageDeclarationAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,12,FOLLOW_12_in_rule__PackageDeclaration__Group__2__Impl937); 
             after(grammarAccess.getPackageDeclarationAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PackageDeclaration__Group__2__Impl"


    // $ANTLR start "rule__PackageDeclaration__Group__3"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:484:1: rule__PackageDeclaration__Group__3 : rule__PackageDeclaration__Group__3__Impl rule__PackageDeclaration__Group__4 ;
    public final void rule__PackageDeclaration__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:488:1: ( rule__PackageDeclaration__Group__3__Impl rule__PackageDeclaration__Group__4 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:489:2: rule__PackageDeclaration__Group__3__Impl rule__PackageDeclaration__Group__4
            {
            pushFollow(FOLLOW_rule__PackageDeclaration__Group__3__Impl_in_rule__PackageDeclaration__Group__3968);
            rule__PackageDeclaration__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__PackageDeclaration__Group__4_in_rule__PackageDeclaration__Group__3971);
            rule__PackageDeclaration__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PackageDeclaration__Group__3"


    // $ANTLR start "rule__PackageDeclaration__Group__3__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:496:1: rule__PackageDeclaration__Group__3__Impl : ( ( rule__PackageDeclaration__ElementsAssignment_3 )* ) ;
    public final void rule__PackageDeclaration__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:500:1: ( ( ( rule__PackageDeclaration__ElementsAssignment_3 )* ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:501:1: ( ( rule__PackageDeclaration__ElementsAssignment_3 )* )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:501:1: ( ( rule__PackageDeclaration__ElementsAssignment_3 )* )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:502:1: ( rule__PackageDeclaration__ElementsAssignment_3 )*
            {
             before(grammarAccess.getPackageDeclarationAccess().getElementsAssignment_3()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:503:1: ( rule__PackageDeclaration__ElementsAssignment_3 )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==11||LA4_0==15||(LA4_0>=17 && LA4_0<=18)) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:503:2: rule__PackageDeclaration__ElementsAssignment_3
            	    {
            	    pushFollow(FOLLOW_rule__PackageDeclaration__ElementsAssignment_3_in_rule__PackageDeclaration__Group__3__Impl998);
            	    rule__PackageDeclaration__ElementsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

             after(grammarAccess.getPackageDeclarationAccess().getElementsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PackageDeclaration__Group__3__Impl"


    // $ANTLR start "rule__PackageDeclaration__Group__4"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:513:1: rule__PackageDeclaration__Group__4 : rule__PackageDeclaration__Group__4__Impl ;
    public final void rule__PackageDeclaration__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:517:1: ( rule__PackageDeclaration__Group__4__Impl )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:518:2: rule__PackageDeclaration__Group__4__Impl
            {
            pushFollow(FOLLOW_rule__PackageDeclaration__Group__4__Impl_in_rule__PackageDeclaration__Group__41029);
            rule__PackageDeclaration__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PackageDeclaration__Group__4"


    // $ANTLR start "rule__PackageDeclaration__Group__4__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:524:1: rule__PackageDeclaration__Group__4__Impl : ( '}' ) ;
    public final void rule__PackageDeclaration__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:528:1: ( ( '}' ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:529:1: ( '}' )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:529:1: ( '}' )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:530:1: '}'
            {
             before(grammarAccess.getPackageDeclarationAccess().getRightCurlyBracketKeyword_4()); 
            match(input,13,FOLLOW_13_in_rule__PackageDeclaration__Group__4__Impl1057); 
             after(grammarAccess.getPackageDeclarationAccess().getRightCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PackageDeclaration__Group__4__Impl"


    // $ANTLR start "rule__QualifiedName__Group__0"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:553:1: rule__QualifiedName__Group__0 : rule__QualifiedName__Group__0__Impl rule__QualifiedName__Group__1 ;
    public final void rule__QualifiedName__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:557:1: ( rule__QualifiedName__Group__0__Impl rule__QualifiedName__Group__1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:558:2: rule__QualifiedName__Group__0__Impl rule__QualifiedName__Group__1
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group__0__Impl_in_rule__QualifiedName__Group__01098);
            rule__QualifiedName__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__QualifiedName__Group__1_in_rule__QualifiedName__Group__01101);
            rule__QualifiedName__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__0"


    // $ANTLR start "rule__QualifiedName__Group__0__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:565:1: rule__QualifiedName__Group__0__Impl : ( RULE_ID ) ;
    public final void rule__QualifiedName__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:569:1: ( ( RULE_ID ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:570:1: ( RULE_ID )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:570:1: ( RULE_ID )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:571:1: RULE_ID
            {
             before(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__QualifiedName__Group__0__Impl1128); 
             after(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__0__Impl"


    // $ANTLR start "rule__QualifiedName__Group__1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:582:1: rule__QualifiedName__Group__1 : rule__QualifiedName__Group__1__Impl ;
    public final void rule__QualifiedName__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:586:1: ( rule__QualifiedName__Group__1__Impl )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:587:2: rule__QualifiedName__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group__1__Impl_in_rule__QualifiedName__Group__11157);
            rule__QualifiedName__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__1"


    // $ANTLR start "rule__QualifiedName__Group__1__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:593:1: rule__QualifiedName__Group__1__Impl : ( ( rule__QualifiedName__Group_1__0 )* ) ;
    public final void rule__QualifiedName__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:597:1: ( ( ( rule__QualifiedName__Group_1__0 )* ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:598:1: ( ( rule__QualifiedName__Group_1__0 )* )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:598:1: ( ( rule__QualifiedName__Group_1__0 )* )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:599:1: ( rule__QualifiedName__Group_1__0 )*
            {
             before(grammarAccess.getQualifiedNameAccess().getGroup_1()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:600:1: ( rule__QualifiedName__Group_1__0 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==14) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:600:2: rule__QualifiedName__Group_1__0
            	    {
            	    pushFollow(FOLLOW_rule__QualifiedName__Group_1__0_in_rule__QualifiedName__Group__1__Impl1184);
            	    rule__QualifiedName__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getQualifiedNameAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__1__Impl"


    // $ANTLR start "rule__QualifiedName__Group_1__0"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:614:1: rule__QualifiedName__Group_1__0 : rule__QualifiedName__Group_1__0__Impl rule__QualifiedName__Group_1__1 ;
    public final void rule__QualifiedName__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:618:1: ( rule__QualifiedName__Group_1__0__Impl rule__QualifiedName__Group_1__1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:619:2: rule__QualifiedName__Group_1__0__Impl rule__QualifiedName__Group_1__1
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group_1__0__Impl_in_rule__QualifiedName__Group_1__01219);
            rule__QualifiedName__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__QualifiedName__Group_1__1_in_rule__QualifiedName__Group_1__01222);
            rule__QualifiedName__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__0"


    // $ANTLR start "rule__QualifiedName__Group_1__0__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:626:1: rule__QualifiedName__Group_1__0__Impl : ( '.' ) ;
    public final void rule__QualifiedName__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:630:1: ( ( '.' ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:631:1: ( '.' )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:631:1: ( '.' )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:632:1: '.'
            {
             before(grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0()); 
            match(input,14,FOLLOW_14_in_rule__QualifiedName__Group_1__0__Impl1250); 
             after(grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__0__Impl"


    // $ANTLR start "rule__QualifiedName__Group_1__1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:645:1: rule__QualifiedName__Group_1__1 : rule__QualifiedName__Group_1__1__Impl ;
    public final void rule__QualifiedName__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:649:1: ( rule__QualifiedName__Group_1__1__Impl )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:650:2: rule__QualifiedName__Group_1__1__Impl
            {
            pushFollow(FOLLOW_rule__QualifiedName__Group_1__1__Impl_in_rule__QualifiedName__Group_1__11281);
            rule__QualifiedName__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__1"


    // $ANTLR start "rule__QualifiedName__Group_1__1__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:656:1: rule__QualifiedName__Group_1__1__Impl : ( RULE_ID ) ;
    public final void rule__QualifiedName__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:660:1: ( ( RULE_ID ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:661:1: ( RULE_ID )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:661:1: ( RULE_ID )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:662:1: RULE_ID
            {
             before(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__QualifiedName__Group_1__1__Impl1308); 
             after(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__1__Impl"


    // $ANTLR start "rule__Import__Group__0"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:677:1: rule__Import__Group__0 : rule__Import__Group__0__Impl rule__Import__Group__1 ;
    public final void rule__Import__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:681:1: ( rule__Import__Group__0__Impl rule__Import__Group__1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:682:2: rule__Import__Group__0__Impl rule__Import__Group__1
            {
            pushFollow(FOLLOW_rule__Import__Group__0__Impl_in_rule__Import__Group__01341);
            rule__Import__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Import__Group__1_in_rule__Import__Group__01344);
            rule__Import__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0"


    // $ANTLR start "rule__Import__Group__0__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:689:1: rule__Import__Group__0__Impl : ( 'import' ) ;
    public final void rule__Import__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:693:1: ( ( 'import' ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:694:1: ( 'import' )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:694:1: ( 'import' )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:695:1: 'import'
            {
             before(grammarAccess.getImportAccess().getImportKeyword_0()); 
            match(input,15,FOLLOW_15_in_rule__Import__Group__0__Impl1372); 
             after(grammarAccess.getImportAccess().getImportKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0__Impl"


    // $ANTLR start "rule__Import__Group__1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:708:1: rule__Import__Group__1 : rule__Import__Group__1__Impl ;
    public final void rule__Import__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:712:1: ( rule__Import__Group__1__Impl )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:713:2: rule__Import__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__Import__Group__1__Impl_in_rule__Import__Group__11403);
            rule__Import__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1"


    // $ANTLR start "rule__Import__Group__1__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:719:1: rule__Import__Group__1__Impl : ( ( rule__Import__ImportedNamespaceAssignment_1 ) ) ;
    public final void rule__Import__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:723:1: ( ( ( rule__Import__ImportedNamespaceAssignment_1 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:724:1: ( ( rule__Import__ImportedNamespaceAssignment_1 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:724:1: ( ( rule__Import__ImportedNamespaceAssignment_1 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:725:1: ( rule__Import__ImportedNamespaceAssignment_1 )
            {
             before(grammarAccess.getImportAccess().getImportedNamespaceAssignment_1()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:726:1: ( rule__Import__ImportedNamespaceAssignment_1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:726:2: rule__Import__ImportedNamespaceAssignment_1
            {
            pushFollow(FOLLOW_rule__Import__ImportedNamespaceAssignment_1_in_rule__Import__Group__1__Impl1430);
            rule__Import__ImportedNamespaceAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getImportedNamespaceAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1__Impl"


    // $ANTLR start "rule__QualifiedNameWithWildcard__Group__0"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:740:1: rule__QualifiedNameWithWildcard__Group__0 : rule__QualifiedNameWithWildcard__Group__0__Impl rule__QualifiedNameWithWildcard__Group__1 ;
    public final void rule__QualifiedNameWithWildcard__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:744:1: ( rule__QualifiedNameWithWildcard__Group__0__Impl rule__QualifiedNameWithWildcard__Group__1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:745:2: rule__QualifiedNameWithWildcard__Group__0__Impl rule__QualifiedNameWithWildcard__Group__1
            {
            pushFollow(FOLLOW_rule__QualifiedNameWithWildcard__Group__0__Impl_in_rule__QualifiedNameWithWildcard__Group__01464);
            rule__QualifiedNameWithWildcard__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__QualifiedNameWithWildcard__Group__1_in_rule__QualifiedNameWithWildcard__Group__01467);
            rule__QualifiedNameWithWildcard__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedNameWithWildcard__Group__0"


    // $ANTLR start "rule__QualifiedNameWithWildcard__Group__0__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:752:1: rule__QualifiedNameWithWildcard__Group__0__Impl : ( ruleQualifiedName ) ;
    public final void rule__QualifiedNameWithWildcard__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:756:1: ( ( ruleQualifiedName ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:757:1: ( ruleQualifiedName )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:757:1: ( ruleQualifiedName )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:758:1: ruleQualifiedName
            {
             before(grammarAccess.getQualifiedNameWithWildcardAccess().getQualifiedNameParserRuleCall_0()); 
            pushFollow(FOLLOW_ruleQualifiedName_in_rule__QualifiedNameWithWildcard__Group__0__Impl1494);
            ruleQualifiedName();

            state._fsp--;

             after(grammarAccess.getQualifiedNameWithWildcardAccess().getQualifiedNameParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedNameWithWildcard__Group__0__Impl"


    // $ANTLR start "rule__QualifiedNameWithWildcard__Group__1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:769:1: rule__QualifiedNameWithWildcard__Group__1 : rule__QualifiedNameWithWildcard__Group__1__Impl ;
    public final void rule__QualifiedNameWithWildcard__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:773:1: ( rule__QualifiedNameWithWildcard__Group__1__Impl )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:774:2: rule__QualifiedNameWithWildcard__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__QualifiedNameWithWildcard__Group__1__Impl_in_rule__QualifiedNameWithWildcard__Group__11523);
            rule__QualifiedNameWithWildcard__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedNameWithWildcard__Group__1"


    // $ANTLR start "rule__QualifiedNameWithWildcard__Group__1__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:780:1: rule__QualifiedNameWithWildcard__Group__1__Impl : ( ( '.*' )? ) ;
    public final void rule__QualifiedNameWithWildcard__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:784:1: ( ( ( '.*' )? ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:785:1: ( ( '.*' )? )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:785:1: ( ( '.*' )? )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:786:1: ( '.*' )?
            {
             before(grammarAccess.getQualifiedNameWithWildcardAccess().getFullStopAsteriskKeyword_1()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:787:1: ( '.*' )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==16) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:788:2: '.*'
                    {
                    match(input,16,FOLLOW_16_in_rule__QualifiedNameWithWildcard__Group__1__Impl1552); 

                    }
                    break;

            }

             after(grammarAccess.getQualifiedNameWithWildcardAccess().getFullStopAsteriskKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedNameWithWildcard__Group__1__Impl"


    // $ANTLR start "rule__DataType__Group__0"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:803:1: rule__DataType__Group__0 : rule__DataType__Group__0__Impl rule__DataType__Group__1 ;
    public final void rule__DataType__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:807:1: ( rule__DataType__Group__0__Impl rule__DataType__Group__1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:808:2: rule__DataType__Group__0__Impl rule__DataType__Group__1
            {
            pushFollow(FOLLOW_rule__DataType__Group__0__Impl_in_rule__DataType__Group__01589);
            rule__DataType__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__DataType__Group__1_in_rule__DataType__Group__01592);
            rule__DataType__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataType__Group__0"


    // $ANTLR start "rule__DataType__Group__0__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:815:1: rule__DataType__Group__0__Impl : ( 'datatype' ) ;
    public final void rule__DataType__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:819:1: ( ( 'datatype' ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:820:1: ( 'datatype' )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:820:1: ( 'datatype' )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:821:1: 'datatype'
            {
             before(grammarAccess.getDataTypeAccess().getDatatypeKeyword_0()); 
            match(input,17,FOLLOW_17_in_rule__DataType__Group__0__Impl1620); 
             after(grammarAccess.getDataTypeAccess().getDatatypeKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataType__Group__0__Impl"


    // $ANTLR start "rule__DataType__Group__1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:834:1: rule__DataType__Group__1 : rule__DataType__Group__1__Impl ;
    public final void rule__DataType__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:838:1: ( rule__DataType__Group__1__Impl )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:839:2: rule__DataType__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__DataType__Group__1__Impl_in_rule__DataType__Group__11651);
            rule__DataType__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataType__Group__1"


    // $ANTLR start "rule__DataType__Group__1__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:845:1: rule__DataType__Group__1__Impl : ( ( rule__DataType__NameAssignment_1 ) ) ;
    public final void rule__DataType__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:849:1: ( ( ( rule__DataType__NameAssignment_1 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:850:1: ( ( rule__DataType__NameAssignment_1 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:850:1: ( ( rule__DataType__NameAssignment_1 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:851:1: ( rule__DataType__NameAssignment_1 )
            {
             before(grammarAccess.getDataTypeAccess().getNameAssignment_1()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:852:1: ( rule__DataType__NameAssignment_1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:852:2: rule__DataType__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__DataType__NameAssignment_1_in_rule__DataType__Group__1__Impl1678);
            rule__DataType__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getDataTypeAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataType__Group__1__Impl"


    // $ANTLR start "rule__Entity__Group__0"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:866:1: rule__Entity__Group__0 : rule__Entity__Group__0__Impl rule__Entity__Group__1 ;
    public final void rule__Entity__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:870:1: ( rule__Entity__Group__0__Impl rule__Entity__Group__1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:871:2: rule__Entity__Group__0__Impl rule__Entity__Group__1
            {
            pushFollow(FOLLOW_rule__Entity__Group__0__Impl_in_rule__Entity__Group__01712);
            rule__Entity__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group__1_in_rule__Entity__Group__01715);
            rule__Entity__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__0"


    // $ANTLR start "rule__Entity__Group__0__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:878:1: rule__Entity__Group__0__Impl : ( 'entity' ) ;
    public final void rule__Entity__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:882:1: ( ( 'entity' ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:883:1: ( 'entity' )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:883:1: ( 'entity' )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:884:1: 'entity'
            {
             before(grammarAccess.getEntityAccess().getEntityKeyword_0()); 
            match(input,18,FOLLOW_18_in_rule__Entity__Group__0__Impl1743); 
             after(grammarAccess.getEntityAccess().getEntityKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__0__Impl"


    // $ANTLR start "rule__Entity__Group__1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:897:1: rule__Entity__Group__1 : rule__Entity__Group__1__Impl rule__Entity__Group__2 ;
    public final void rule__Entity__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:901:1: ( rule__Entity__Group__1__Impl rule__Entity__Group__2 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:902:2: rule__Entity__Group__1__Impl rule__Entity__Group__2
            {
            pushFollow(FOLLOW_rule__Entity__Group__1__Impl_in_rule__Entity__Group__11774);
            rule__Entity__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group__2_in_rule__Entity__Group__11777);
            rule__Entity__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__1"


    // $ANTLR start "rule__Entity__Group__1__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:909:1: rule__Entity__Group__1__Impl : ( ( rule__Entity__NameAssignment_1 ) ) ;
    public final void rule__Entity__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:913:1: ( ( ( rule__Entity__NameAssignment_1 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:914:1: ( ( rule__Entity__NameAssignment_1 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:914:1: ( ( rule__Entity__NameAssignment_1 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:915:1: ( rule__Entity__NameAssignment_1 )
            {
             before(grammarAccess.getEntityAccess().getNameAssignment_1()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:916:1: ( rule__Entity__NameAssignment_1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:916:2: rule__Entity__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__Entity__NameAssignment_1_in_rule__Entity__Group__1__Impl1804);
            rule__Entity__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEntityAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__1__Impl"


    // $ANTLR start "rule__Entity__Group__2"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:926:1: rule__Entity__Group__2 : rule__Entity__Group__2__Impl rule__Entity__Group__3 ;
    public final void rule__Entity__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:930:1: ( rule__Entity__Group__2__Impl rule__Entity__Group__3 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:931:2: rule__Entity__Group__2__Impl rule__Entity__Group__3
            {
            pushFollow(FOLLOW_rule__Entity__Group__2__Impl_in_rule__Entity__Group__21834);
            rule__Entity__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group__3_in_rule__Entity__Group__21837);
            rule__Entity__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__2"


    // $ANTLR start "rule__Entity__Group__2__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:938:1: rule__Entity__Group__2__Impl : ( ( rule__Entity__Group_2__0 )? ) ;
    public final void rule__Entity__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:942:1: ( ( ( rule__Entity__Group_2__0 )? ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:943:1: ( ( rule__Entity__Group_2__0 )? )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:943:1: ( ( rule__Entity__Group_2__0 )? )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:944:1: ( rule__Entity__Group_2__0 )?
            {
             before(grammarAccess.getEntityAccess().getGroup_2()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:945:1: ( rule__Entity__Group_2__0 )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==19) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:945:2: rule__Entity__Group_2__0
                    {
                    pushFollow(FOLLOW_rule__Entity__Group_2__0_in_rule__Entity__Group__2__Impl1864);
                    rule__Entity__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEntityAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__2__Impl"


    // $ANTLR start "rule__Entity__Group__3"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:955:1: rule__Entity__Group__3 : rule__Entity__Group__3__Impl rule__Entity__Group__4 ;
    public final void rule__Entity__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:959:1: ( rule__Entity__Group__3__Impl rule__Entity__Group__4 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:960:2: rule__Entity__Group__3__Impl rule__Entity__Group__4
            {
            pushFollow(FOLLOW_rule__Entity__Group__3__Impl_in_rule__Entity__Group__31895);
            rule__Entity__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group__4_in_rule__Entity__Group__31898);
            rule__Entity__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__3"


    // $ANTLR start "rule__Entity__Group__3__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:967:1: rule__Entity__Group__3__Impl : ( '{' ) ;
    public final void rule__Entity__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:971:1: ( ( '{' ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:972:1: ( '{' )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:972:1: ( '{' )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:973:1: '{'
            {
             before(grammarAccess.getEntityAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,12,FOLLOW_12_in_rule__Entity__Group__3__Impl1926); 
             after(grammarAccess.getEntityAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__3__Impl"


    // $ANTLR start "rule__Entity__Group__4"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:986:1: rule__Entity__Group__4 : rule__Entity__Group__4__Impl rule__Entity__Group__5 ;
    public final void rule__Entity__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:990:1: ( rule__Entity__Group__4__Impl rule__Entity__Group__5 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:991:2: rule__Entity__Group__4__Impl rule__Entity__Group__5
            {
            pushFollow(FOLLOW_rule__Entity__Group__4__Impl_in_rule__Entity__Group__41957);
            rule__Entity__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group__5_in_rule__Entity__Group__41960);
            rule__Entity__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__4"


    // $ANTLR start "rule__Entity__Group__4__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:998:1: rule__Entity__Group__4__Impl : ( ( rule__Entity__FeaturesAssignment_4 )* ) ;
    public final void rule__Entity__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1002:1: ( ( ( rule__Entity__FeaturesAssignment_4 )* ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1003:1: ( ( rule__Entity__FeaturesAssignment_4 )* )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1003:1: ( ( rule__Entity__FeaturesAssignment_4 )* )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1004:1: ( rule__Entity__FeaturesAssignment_4 )*
            {
             before(grammarAccess.getEntityAccess().getFeaturesAssignment_4()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1005:1: ( rule__Entity__FeaturesAssignment_4 )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==RULE_ID||LA8_0==21) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1005:2: rule__Entity__FeaturesAssignment_4
            	    {
            	    pushFollow(FOLLOW_rule__Entity__FeaturesAssignment_4_in_rule__Entity__Group__4__Impl1987);
            	    rule__Entity__FeaturesAssignment_4();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

             after(grammarAccess.getEntityAccess().getFeaturesAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__4__Impl"


    // $ANTLR start "rule__Entity__Group__5"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1015:1: rule__Entity__Group__5 : rule__Entity__Group__5__Impl ;
    public final void rule__Entity__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1019:1: ( rule__Entity__Group__5__Impl )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1020:2: rule__Entity__Group__5__Impl
            {
            pushFollow(FOLLOW_rule__Entity__Group__5__Impl_in_rule__Entity__Group__52018);
            rule__Entity__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__5"


    // $ANTLR start "rule__Entity__Group__5__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1026:1: rule__Entity__Group__5__Impl : ( '}' ) ;
    public final void rule__Entity__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1030:1: ( ( '}' ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1031:1: ( '}' )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1031:1: ( '}' )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1032:1: '}'
            {
             before(grammarAccess.getEntityAccess().getRightCurlyBracketKeyword_5()); 
            match(input,13,FOLLOW_13_in_rule__Entity__Group__5__Impl2046); 
             after(grammarAccess.getEntityAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group__5__Impl"


    // $ANTLR start "rule__Entity__Group_2__0"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1057:1: rule__Entity__Group_2__0 : rule__Entity__Group_2__0__Impl rule__Entity__Group_2__1 ;
    public final void rule__Entity__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1061:1: ( rule__Entity__Group_2__0__Impl rule__Entity__Group_2__1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1062:2: rule__Entity__Group_2__0__Impl rule__Entity__Group_2__1
            {
            pushFollow(FOLLOW_rule__Entity__Group_2__0__Impl_in_rule__Entity__Group_2__02089);
            rule__Entity__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Entity__Group_2__1_in_rule__Entity__Group_2__02092);
            rule__Entity__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group_2__0"


    // $ANTLR start "rule__Entity__Group_2__0__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1069:1: rule__Entity__Group_2__0__Impl : ( 'extends' ) ;
    public final void rule__Entity__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1073:1: ( ( 'extends' ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1074:1: ( 'extends' )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1074:1: ( 'extends' )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1075:1: 'extends'
            {
             before(grammarAccess.getEntityAccess().getExtendsKeyword_2_0()); 
            match(input,19,FOLLOW_19_in_rule__Entity__Group_2__0__Impl2120); 
             after(grammarAccess.getEntityAccess().getExtendsKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group_2__0__Impl"


    // $ANTLR start "rule__Entity__Group_2__1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1088:1: rule__Entity__Group_2__1 : rule__Entity__Group_2__1__Impl ;
    public final void rule__Entity__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1092:1: ( rule__Entity__Group_2__1__Impl )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1093:2: rule__Entity__Group_2__1__Impl
            {
            pushFollow(FOLLOW_rule__Entity__Group_2__1__Impl_in_rule__Entity__Group_2__12151);
            rule__Entity__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group_2__1"


    // $ANTLR start "rule__Entity__Group_2__1__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1099:1: rule__Entity__Group_2__1__Impl : ( ( rule__Entity__SuperTypeAssignment_2_1 ) ) ;
    public final void rule__Entity__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1103:1: ( ( ( rule__Entity__SuperTypeAssignment_2_1 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1104:1: ( ( rule__Entity__SuperTypeAssignment_2_1 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1104:1: ( ( rule__Entity__SuperTypeAssignment_2_1 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1105:1: ( rule__Entity__SuperTypeAssignment_2_1 )
            {
             before(grammarAccess.getEntityAccess().getSuperTypeAssignment_2_1()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1106:1: ( rule__Entity__SuperTypeAssignment_2_1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1106:2: rule__Entity__SuperTypeAssignment_2_1
            {
            pushFollow(FOLLOW_rule__Entity__SuperTypeAssignment_2_1_in_rule__Entity__Group_2__1__Impl2178);
            rule__Entity__SuperTypeAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getEntityAccess().getSuperTypeAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__Group_2__1__Impl"


    // $ANTLR start "rule__Feature__Group__0"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1120:1: rule__Feature__Group__0 : rule__Feature__Group__0__Impl rule__Feature__Group__1 ;
    public final void rule__Feature__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1124:1: ( rule__Feature__Group__0__Impl rule__Feature__Group__1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1125:2: rule__Feature__Group__0__Impl rule__Feature__Group__1
            {
            pushFollow(FOLLOW_rule__Feature__Group__0__Impl_in_rule__Feature__Group__02212);
            rule__Feature__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Feature__Group__1_in_rule__Feature__Group__02215);
            rule__Feature__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__0"


    // $ANTLR start "rule__Feature__Group__0__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1132:1: rule__Feature__Group__0__Impl : ( ( rule__Feature__ManyAssignment_0 )? ) ;
    public final void rule__Feature__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1136:1: ( ( ( rule__Feature__ManyAssignment_0 )? ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1137:1: ( ( rule__Feature__ManyAssignment_0 )? )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1137:1: ( ( rule__Feature__ManyAssignment_0 )? )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1138:1: ( rule__Feature__ManyAssignment_0 )?
            {
             before(grammarAccess.getFeatureAccess().getManyAssignment_0()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1139:1: ( rule__Feature__ManyAssignment_0 )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==21) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1139:2: rule__Feature__ManyAssignment_0
                    {
                    pushFollow(FOLLOW_rule__Feature__ManyAssignment_0_in_rule__Feature__Group__0__Impl2242);
                    rule__Feature__ManyAssignment_0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFeatureAccess().getManyAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__0__Impl"


    // $ANTLR start "rule__Feature__Group__1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1149:1: rule__Feature__Group__1 : rule__Feature__Group__1__Impl rule__Feature__Group__2 ;
    public final void rule__Feature__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1153:1: ( rule__Feature__Group__1__Impl rule__Feature__Group__2 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1154:2: rule__Feature__Group__1__Impl rule__Feature__Group__2
            {
            pushFollow(FOLLOW_rule__Feature__Group__1__Impl_in_rule__Feature__Group__12273);
            rule__Feature__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Feature__Group__2_in_rule__Feature__Group__12276);
            rule__Feature__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__1"


    // $ANTLR start "rule__Feature__Group__1__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1161:1: rule__Feature__Group__1__Impl : ( ( rule__Feature__NameAssignment_1 ) ) ;
    public final void rule__Feature__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1165:1: ( ( ( rule__Feature__NameAssignment_1 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1166:1: ( ( rule__Feature__NameAssignment_1 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1166:1: ( ( rule__Feature__NameAssignment_1 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1167:1: ( rule__Feature__NameAssignment_1 )
            {
             before(grammarAccess.getFeatureAccess().getNameAssignment_1()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1168:1: ( rule__Feature__NameAssignment_1 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1168:2: rule__Feature__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__Feature__NameAssignment_1_in_rule__Feature__Group__1__Impl2303);
            rule__Feature__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getFeatureAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__1__Impl"


    // $ANTLR start "rule__Feature__Group__2"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1178:1: rule__Feature__Group__2 : rule__Feature__Group__2__Impl rule__Feature__Group__3 ;
    public final void rule__Feature__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1182:1: ( rule__Feature__Group__2__Impl rule__Feature__Group__3 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1183:2: rule__Feature__Group__2__Impl rule__Feature__Group__3
            {
            pushFollow(FOLLOW_rule__Feature__Group__2__Impl_in_rule__Feature__Group__22333);
            rule__Feature__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Feature__Group__3_in_rule__Feature__Group__22336);
            rule__Feature__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__2"


    // $ANTLR start "rule__Feature__Group__2__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1190:1: rule__Feature__Group__2__Impl : ( ':' ) ;
    public final void rule__Feature__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1194:1: ( ( ':' ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1195:1: ( ':' )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1195:1: ( ':' )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1196:1: ':'
            {
             before(grammarAccess.getFeatureAccess().getColonKeyword_2()); 
            match(input,20,FOLLOW_20_in_rule__Feature__Group__2__Impl2364); 
             after(grammarAccess.getFeatureAccess().getColonKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__2__Impl"


    // $ANTLR start "rule__Feature__Group__3"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1209:1: rule__Feature__Group__3 : rule__Feature__Group__3__Impl ;
    public final void rule__Feature__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1213:1: ( rule__Feature__Group__3__Impl )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1214:2: rule__Feature__Group__3__Impl
            {
            pushFollow(FOLLOW_rule__Feature__Group__3__Impl_in_rule__Feature__Group__32395);
            rule__Feature__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__3"


    // $ANTLR start "rule__Feature__Group__3__Impl"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1220:1: rule__Feature__Group__3__Impl : ( ( rule__Feature__TypeAssignment_3 ) ) ;
    public final void rule__Feature__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1224:1: ( ( ( rule__Feature__TypeAssignment_3 ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1225:1: ( ( rule__Feature__TypeAssignment_3 ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1225:1: ( ( rule__Feature__TypeAssignment_3 ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1226:1: ( rule__Feature__TypeAssignment_3 )
            {
             before(grammarAccess.getFeatureAccess().getTypeAssignment_3()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1227:1: ( rule__Feature__TypeAssignment_3 )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1227:2: rule__Feature__TypeAssignment_3
            {
            pushFollow(FOLLOW_rule__Feature__TypeAssignment_3_in_rule__Feature__Group__3__Impl2422);
            rule__Feature__TypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getFeatureAccess().getTypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__3__Impl"


    // $ANTLR start "rule__Domainmodel__ElementsAssignment"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1246:1: rule__Domainmodel__ElementsAssignment : ( ruleAbstractElement ) ;
    public final void rule__Domainmodel__ElementsAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1250:1: ( ( ruleAbstractElement ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1251:1: ( ruleAbstractElement )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1251:1: ( ruleAbstractElement )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1252:1: ruleAbstractElement
            {
             before(grammarAccess.getDomainmodelAccess().getElementsAbstractElementParserRuleCall_0()); 
            pushFollow(FOLLOW_ruleAbstractElement_in_rule__Domainmodel__ElementsAssignment2465);
            ruleAbstractElement();

            state._fsp--;

             after(grammarAccess.getDomainmodelAccess().getElementsAbstractElementParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Domainmodel__ElementsAssignment"


    // $ANTLR start "rule__PackageDeclaration__NameAssignment_1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1261:1: rule__PackageDeclaration__NameAssignment_1 : ( ruleQualifiedName ) ;
    public final void rule__PackageDeclaration__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1265:1: ( ( ruleQualifiedName ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1266:1: ( ruleQualifiedName )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1266:1: ( ruleQualifiedName )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1267:1: ruleQualifiedName
            {
             before(grammarAccess.getPackageDeclarationAccess().getNameQualifiedNameParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleQualifiedName_in_rule__PackageDeclaration__NameAssignment_12496);
            ruleQualifiedName();

            state._fsp--;

             after(grammarAccess.getPackageDeclarationAccess().getNameQualifiedNameParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PackageDeclaration__NameAssignment_1"


    // $ANTLR start "rule__PackageDeclaration__ElementsAssignment_3"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1276:1: rule__PackageDeclaration__ElementsAssignment_3 : ( ruleAbstractElement ) ;
    public final void rule__PackageDeclaration__ElementsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1280:1: ( ( ruleAbstractElement ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1281:1: ( ruleAbstractElement )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1281:1: ( ruleAbstractElement )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1282:1: ruleAbstractElement
            {
             before(grammarAccess.getPackageDeclarationAccess().getElementsAbstractElementParserRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleAbstractElement_in_rule__PackageDeclaration__ElementsAssignment_32527);
            ruleAbstractElement();

            state._fsp--;

             after(grammarAccess.getPackageDeclarationAccess().getElementsAbstractElementParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PackageDeclaration__ElementsAssignment_3"


    // $ANTLR start "rule__Import__ImportedNamespaceAssignment_1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1291:1: rule__Import__ImportedNamespaceAssignment_1 : ( ruleQualifiedNameWithWildcard ) ;
    public final void rule__Import__ImportedNamespaceAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1295:1: ( ( ruleQualifiedNameWithWildcard ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1296:1: ( ruleQualifiedNameWithWildcard )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1296:1: ( ruleQualifiedNameWithWildcard )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1297:1: ruleQualifiedNameWithWildcard
            {
             before(grammarAccess.getImportAccess().getImportedNamespaceQualifiedNameWithWildcardParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleQualifiedNameWithWildcard_in_rule__Import__ImportedNamespaceAssignment_12558);
            ruleQualifiedNameWithWildcard();

            state._fsp--;

             after(grammarAccess.getImportAccess().getImportedNamespaceQualifiedNameWithWildcardParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__ImportedNamespaceAssignment_1"


    // $ANTLR start "rule__DataType__NameAssignment_1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1306:1: rule__DataType__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__DataType__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1310:1: ( ( RULE_ID ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1311:1: ( RULE_ID )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1311:1: ( RULE_ID )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1312:1: RULE_ID
            {
             before(grammarAccess.getDataTypeAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__DataType__NameAssignment_12589); 
             after(grammarAccess.getDataTypeAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataType__NameAssignment_1"


    // $ANTLR start "rule__Entity__NameAssignment_1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1321:1: rule__Entity__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Entity__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1325:1: ( ( RULE_ID ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1326:1: ( RULE_ID )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1326:1: ( RULE_ID )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1327:1: RULE_ID
            {
             before(grammarAccess.getEntityAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Entity__NameAssignment_12620); 
             after(grammarAccess.getEntityAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__NameAssignment_1"


    // $ANTLR start "rule__Entity__SuperTypeAssignment_2_1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1336:1: rule__Entity__SuperTypeAssignment_2_1 : ( ( ruleQualifiedName ) ) ;
    public final void rule__Entity__SuperTypeAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1340:1: ( ( ( ruleQualifiedName ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1341:1: ( ( ruleQualifiedName ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1341:1: ( ( ruleQualifiedName ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1342:1: ( ruleQualifiedName )
            {
             before(grammarAccess.getEntityAccess().getSuperTypeEntityCrossReference_2_1_0()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1343:1: ( ruleQualifiedName )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1344:1: ruleQualifiedName
            {
             before(grammarAccess.getEntityAccess().getSuperTypeEntityQualifiedNameParserRuleCall_2_1_0_1()); 
            pushFollow(FOLLOW_ruleQualifiedName_in_rule__Entity__SuperTypeAssignment_2_12655);
            ruleQualifiedName();

            state._fsp--;

             after(grammarAccess.getEntityAccess().getSuperTypeEntityQualifiedNameParserRuleCall_2_1_0_1()); 

            }

             after(grammarAccess.getEntityAccess().getSuperTypeEntityCrossReference_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__SuperTypeAssignment_2_1"


    // $ANTLR start "rule__Entity__FeaturesAssignment_4"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1355:1: rule__Entity__FeaturesAssignment_4 : ( ruleFeature ) ;
    public final void rule__Entity__FeaturesAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1359:1: ( ( ruleFeature ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1360:1: ( ruleFeature )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1360:1: ( ruleFeature )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1361:1: ruleFeature
            {
             before(grammarAccess.getEntityAccess().getFeaturesFeatureParserRuleCall_4_0()); 
            pushFollow(FOLLOW_ruleFeature_in_rule__Entity__FeaturesAssignment_42690);
            ruleFeature();

            state._fsp--;

             after(grammarAccess.getEntityAccess().getFeaturesFeatureParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Entity__FeaturesAssignment_4"


    // $ANTLR start "rule__Feature__ManyAssignment_0"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1370:1: rule__Feature__ManyAssignment_0 : ( ( 'many' ) ) ;
    public final void rule__Feature__ManyAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1374:1: ( ( ( 'many' ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1375:1: ( ( 'many' ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1375:1: ( ( 'many' ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1376:1: ( 'many' )
            {
             before(grammarAccess.getFeatureAccess().getManyManyKeyword_0_0()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1377:1: ( 'many' )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1378:1: 'many'
            {
             before(grammarAccess.getFeatureAccess().getManyManyKeyword_0_0()); 
            match(input,21,FOLLOW_21_in_rule__Feature__ManyAssignment_02726); 
             after(grammarAccess.getFeatureAccess().getManyManyKeyword_0_0()); 

            }

             after(grammarAccess.getFeatureAccess().getManyManyKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__ManyAssignment_0"


    // $ANTLR start "rule__Feature__NameAssignment_1"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1393:1: rule__Feature__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Feature__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1397:1: ( ( RULE_ID ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1398:1: ( RULE_ID )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1398:1: ( RULE_ID )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1399:1: RULE_ID
            {
             before(grammarAccess.getFeatureAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Feature__NameAssignment_12765); 
             after(grammarAccess.getFeatureAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__NameAssignment_1"


    // $ANTLR start "rule__Feature__TypeAssignment_3"
    // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1408:1: rule__Feature__TypeAssignment_3 : ( ( ruleQualifiedName ) ) ;
    public final void rule__Feature__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1412:1: ( ( ( ruleQualifiedName ) ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1413:1: ( ( ruleQualifiedName ) )
            {
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1413:1: ( ( ruleQualifiedName ) )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1414:1: ( ruleQualifiedName )
            {
             before(grammarAccess.getFeatureAccess().getTypeTypeCrossReference_3_0()); 
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1415:1: ( ruleQualifiedName )
            // ../org.example.domainmodel.ui/src-gen/org/example/domainmodel/ui/contentassist/antlr/internal/InternalDomainmodel.g:1416:1: ruleQualifiedName
            {
             before(grammarAccess.getFeatureAccess().getTypeTypeQualifiedNameParserRuleCall_3_0_1()); 
            pushFollow(FOLLOW_ruleQualifiedName_in_rule__Feature__TypeAssignment_32800);
            ruleQualifiedName();

            state._fsp--;

             after(grammarAccess.getFeatureAccess().getTypeTypeQualifiedNameParserRuleCall_3_0_1()); 

            }

             after(grammarAccess.getFeatureAccess().getTypeTypeCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__TypeAssignment_3"

    // Delegated rules


 

    public static final BitSet FOLLOW_ruleDomainmodel_in_entryRuleDomainmodel61 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleDomainmodel68 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Domainmodel__ElementsAssignment_in_ruleDomainmodel94 = new BitSet(new long[]{0x0000000000068802L});
    public static final BitSet FOLLOW_rulePackageDeclaration_in_entryRulePackageDeclaration122 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulePackageDeclaration129 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__PackageDeclaration__Group__0_in_rulePackageDeclaration155 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAbstractElement_in_entryRuleAbstractElement182 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAbstractElement189 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AbstractElement__Alternatives_in_ruleAbstractElement215 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_entryRuleQualifiedName242 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleQualifiedName249 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group__0_in_ruleQualifiedName275 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleImport_in_entryRuleImport302 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleImport309 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Import__Group__0_in_ruleImport335 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedNameWithWildcard_in_entryRuleQualifiedNameWithWildcard362 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleQualifiedNameWithWildcard369 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedNameWithWildcard__Group__0_in_ruleQualifiedNameWithWildcard395 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleType_in_entryRuleType422 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleType429 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Type__Alternatives_in_ruleType455 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleDataType_in_entryRuleDataType482 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleDataType489 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__DataType__Group__0_in_ruleDataType515 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntity_in_entryRuleEntity542 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEntity549 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__0_in_ruleEntity575 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeature_in_entryRuleFeature602 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeature609 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group__0_in_ruleFeature635 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePackageDeclaration_in_rule__AbstractElement__Alternatives671 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleType_in_rule__AbstractElement__Alternatives688 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleImport_in_rule__AbstractElement__Alternatives705 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleDataType_in_rule__Type__Alternatives737 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntity_in_rule__Type__Alternatives754 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__PackageDeclaration__Group__0__Impl_in_rule__PackageDeclaration__Group__0784 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__PackageDeclaration__Group__1_in_rule__PackageDeclaration__Group__0787 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_rule__PackageDeclaration__Group__0__Impl815 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__PackageDeclaration__Group__1__Impl_in_rule__PackageDeclaration__Group__1846 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_rule__PackageDeclaration__Group__2_in_rule__PackageDeclaration__Group__1849 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__PackageDeclaration__NameAssignment_1_in_rule__PackageDeclaration__Group__1__Impl876 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__PackageDeclaration__Group__2__Impl_in_rule__PackageDeclaration__Group__2906 = new BitSet(new long[]{0x000000000006A800L});
    public static final BitSet FOLLOW_rule__PackageDeclaration__Group__3_in_rule__PackageDeclaration__Group__2909 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_12_in_rule__PackageDeclaration__Group__2__Impl937 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__PackageDeclaration__Group__3__Impl_in_rule__PackageDeclaration__Group__3968 = new BitSet(new long[]{0x000000000006A800L});
    public static final BitSet FOLLOW_rule__PackageDeclaration__Group__4_in_rule__PackageDeclaration__Group__3971 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__PackageDeclaration__ElementsAssignment_3_in_rule__PackageDeclaration__Group__3__Impl998 = new BitSet(new long[]{0x0000000000068802L});
    public static final BitSet FOLLOW_rule__PackageDeclaration__Group__4__Impl_in_rule__PackageDeclaration__Group__41029 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_rule__PackageDeclaration__Group__4__Impl1057 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group__0__Impl_in_rule__QualifiedName__Group__01098 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group__1_in_rule__QualifiedName__Group__01101 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__QualifiedName__Group__0__Impl1128 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group__1__Impl_in_rule__QualifiedName__Group__11157 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group_1__0_in_rule__QualifiedName__Group__1__Impl1184 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group_1__0__Impl_in_rule__QualifiedName__Group_1__01219 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group_1__1_in_rule__QualifiedName__Group_1__01222 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_14_in_rule__QualifiedName__Group_1__0__Impl1250 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedName__Group_1__1__Impl_in_rule__QualifiedName__Group_1__11281 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__QualifiedName__Group_1__1__Impl1308 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Import__Group__0__Impl_in_rule__Import__Group__01341 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Import__Group__1_in_rule__Import__Group__01344 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_rule__Import__Group__0__Impl1372 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Import__Group__1__Impl_in_rule__Import__Group__11403 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Import__ImportedNamespaceAssignment_1_in_rule__Import__Group__1__Impl1430 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedNameWithWildcard__Group__0__Impl_in_rule__QualifiedNameWithWildcard__Group__01464 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_rule__QualifiedNameWithWildcard__Group__1_in_rule__QualifiedNameWithWildcard__Group__01467 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_rule__QualifiedNameWithWildcard__Group__0__Impl1494 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__QualifiedNameWithWildcard__Group__1__Impl_in_rule__QualifiedNameWithWildcard__Group__11523 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_rule__QualifiedNameWithWildcard__Group__1__Impl1552 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__DataType__Group__0__Impl_in_rule__DataType__Group__01589 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__DataType__Group__1_in_rule__DataType__Group__01592 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_rule__DataType__Group__0__Impl1620 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__DataType__Group__1__Impl_in_rule__DataType__Group__11651 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__DataType__NameAssignment_1_in_rule__DataType__Group__1__Impl1678 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__0__Impl_in_rule__Entity__Group__01712 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Entity__Group__1_in_rule__Entity__Group__01715 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_rule__Entity__Group__0__Impl1743 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__1__Impl_in_rule__Entity__Group__11774 = new BitSet(new long[]{0x0000000000081000L});
    public static final BitSet FOLLOW_rule__Entity__Group__2_in_rule__Entity__Group__11777 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__NameAssignment_1_in_rule__Entity__Group__1__Impl1804 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__2__Impl_in_rule__Entity__Group__21834 = new BitSet(new long[]{0x0000000000081000L});
    public static final BitSet FOLLOW_rule__Entity__Group__3_in_rule__Entity__Group__21837 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group_2__0_in_rule__Entity__Group__2__Impl1864 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__3__Impl_in_rule__Entity__Group__31895 = new BitSet(new long[]{0x0000000000202010L});
    public static final BitSet FOLLOW_rule__Entity__Group__4_in_rule__Entity__Group__31898 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_12_in_rule__Entity__Group__3__Impl1926 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__4__Impl_in_rule__Entity__Group__41957 = new BitSet(new long[]{0x0000000000202010L});
    public static final BitSet FOLLOW_rule__Entity__Group__5_in_rule__Entity__Group__41960 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__FeaturesAssignment_4_in_rule__Entity__Group__4__Impl1987 = new BitSet(new long[]{0x0000000000200012L});
    public static final BitSet FOLLOW_rule__Entity__Group__5__Impl_in_rule__Entity__Group__52018 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_rule__Entity__Group__5__Impl2046 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group_2__0__Impl_in_rule__Entity__Group_2__02089 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Entity__Group_2__1_in_rule__Entity__Group_2__02092 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_rule__Entity__Group_2__0__Impl2120 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group_2__1__Impl_in_rule__Entity__Group_2__12151 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__SuperTypeAssignment_2_1_in_rule__Entity__Group_2__1__Impl2178 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group__0__Impl_in_rule__Feature__Group__02212 = new BitSet(new long[]{0x0000000000200010L});
    public static final BitSet FOLLOW_rule__Feature__Group__1_in_rule__Feature__Group__02215 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__ManyAssignment_0_in_rule__Feature__Group__0__Impl2242 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group__1__Impl_in_rule__Feature__Group__12273 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_rule__Feature__Group__2_in_rule__Feature__Group__12276 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__NameAssignment_1_in_rule__Feature__Group__1__Impl2303 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group__2__Impl_in_rule__Feature__Group__22333 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Feature__Group__3_in_rule__Feature__Group__22336 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_rule__Feature__Group__2__Impl2364 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group__3__Impl_in_rule__Feature__Group__32395 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__TypeAssignment_3_in_rule__Feature__Group__3__Impl2422 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAbstractElement_in_rule__Domainmodel__ElementsAssignment2465 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_rule__PackageDeclaration__NameAssignment_12496 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAbstractElement_in_rule__PackageDeclaration__ElementsAssignment_32527 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedNameWithWildcard_in_rule__Import__ImportedNamespaceAssignment_12558 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__DataType__NameAssignment_12589 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Entity__NameAssignment_12620 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_rule__Entity__SuperTypeAssignment_2_12655 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeature_in_rule__Entity__FeaturesAssignment_42690 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_rule__Feature__ManyAssignment_02726 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Feature__NameAssignment_12765 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleQualifiedName_in_rule__Feature__TypeAssignment_32800 = new BitSet(new long[]{0x0000000000000002L});

}