package org.example.domainmodel.serializer;

public class DomainmodelSemanticSequencer extends AbstractDomainmodelSemanticSequencer {
}
