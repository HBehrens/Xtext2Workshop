/**
 * <copyright>
 * </copyright>
 *
 */
package org.example.domainmodel.domainmodel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Data Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.example.domainmodel.domainmodel.DomainmodelPackage#getDataType()
 * @model
 * @generated
 */
public interface DataType extends Type
{
} // DataType
