package org.example.domainmodel.generator;

import com.google.inject.Inject;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.naming.IQualifiedNameProvider;
import org.eclipse.xtext.naming.QualifiedName;
import org.eclipse.xtext.xbase.lib.BooleanExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.StringExtensions;
import org.example.domainmodel.domainmodel.DataType;
import org.example.domainmodel.domainmodel.Entity;
import org.example.domainmodel.domainmodel.PackageDeclaration;

@SuppressWarnings("all")
public class GeneratorNameProvider {
  
  @Inject
  private IQualifiedNameProvider qualifiedNameProvider;
  
  protected QualifiedName _qualifiedName(final Entity entity) {
    String _name = entity.getName();
    QualifiedName _qualifiedName = this.toQualifiedName(_name);
    return _qualifiedName;
  }
  
  protected QualifiedName _qualifiedName(final DataType dataType) {
    QualifiedName _xblockexpression = null;
    {
      PackageDeclaration _containerOfType = EcoreUtil2.<PackageDeclaration>getContainerOfType(dataType, org.example.domainmodel.domainmodel.PackageDeclaration.class);
      final PackageDeclaration packageDeclaration = _containerOfType;
      QualifiedName _xifexpression = null;
      boolean _operator_or = false;
      boolean _operator_equals = ObjectExtensions.operator_equals(packageDeclaration, null);
      if (_operator_equals) {
        _operator_or = true;
      } else {
        String _name = packageDeclaration.getName();
        boolean _equals = _name.equals("java.lang");
        _operator_or = BooleanExtensions.operator_or(_operator_equals, _equals);
      }
      if (_operator_or) {
        String _name_1 = dataType.getName();
        QualifiedName _qualifiedName = this.toQualifiedName(_name_1);
        return _qualifiedName;
      } else {
        String _name_2 = packageDeclaration.getName();
        String _operator_plus = StringExtensions.operator_plus(_name_2, ".");
        String _name_3 = dataType.getName();
        String _operator_plus_1 = StringExtensions.operator_plus(_operator_plus, _name_3);
        QualifiedName _qualifiedName_1 = this.toQualifiedName(_operator_plus_1);
        _xifexpression = _qualifiedName_1;
      }
      _xblockexpression = (_xifexpression);
    }
    return _xblockexpression;
  }
  
  protected QualifiedName _qualifiedName(final EObject eObject) {
    QualifiedName _fullyQualifiedName = this.qualifiedNameProvider.getFullyQualifiedName(eObject);
    return _fullyQualifiedName;
  }
  
  public QualifiedName toQualifiedName(final String name) {
    QualifiedName _create = QualifiedName.create(name);
    return _create;
  }
  
  public QualifiedName fullyQualifiedName(final EObject eObject) {
    QualifiedName _qualifiedName = this.qualifiedName(eObject);
    return _qualifiedName;
  }
  
  public QualifiedName qualifiedName(final EObject dataType) {
    if ((dataType instanceof DataType)) {
      return _qualifiedName((DataType)dataType);
    } else if ((dataType instanceof Entity)) {
      return _qualifiedName((Entity)dataType);
    } else if ((dataType instanceof EObject)) {
      return _qualifiedName((EObject)dataType);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        java.util.Arrays.<Object>asList(dataType).toString());
    }
  }
}