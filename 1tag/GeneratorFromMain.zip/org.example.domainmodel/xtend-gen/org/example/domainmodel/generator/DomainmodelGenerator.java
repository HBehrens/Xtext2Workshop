package org.example.domainmodel.generator;

import com.google.inject.Inject;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.generator.IFileSystemAccess;
import org.eclipse.xtext.generator.IGenerator;
import org.eclipse.xtext.naming.QualifiedName;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.StringExtensions;
import org.eclipse.xtext.xtend2.lib.ResourceExtensions;
import org.eclipse.xtext.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.Entity;
import org.example.domainmodel.domainmodel.Feature;
import org.example.domainmodel.domainmodel.Type;
import org.example.domainmodel.generator.GeneratorNameProvider;

@SuppressWarnings("all")
public class DomainmodelGenerator implements IGenerator {
  
  @Inject
  private GeneratorNameProvider nameProvider;
  
  public void doGenerate(final Resource resource, final IFileSystemAccess fsa) {
    Iterable<EObject> _allContentsIterable = ResourceExtensions.allContentsIterable(resource);
    Iterable<Entity> _filter = IterableExtensions.<Entity>filter(_allContentsIterable, org.example.domainmodel.domainmodel.Entity.class);
    for (Entity e : _filter) {
      EObject _eContainer = e.eContainer();
      QualifiedName _fullyQualifiedName = this.nameProvider.fullyQualifiedName(_eContainer);
      String _string = _fullyQualifiedName.toString();
      String _operator_plus = StringExtensions.operator_plus(_string, ".");
      String _name = e.getName();
      String _operator_plus_1 = StringExtensions.operator_plus(_operator_plus, _name);
      String _replace = _operator_plus_1.replace(".", "/");
      String _operator_plus_2 = StringExtensions.operator_plus(_replace, ".java");
      StringConcatenation _compile = this.compile(e);
      fsa.generateFile(_operator_plus_2, _compile);
    }
  }
  
  public StringConcatenation compile(final Entity e) {
    StringConcatenation _builder = new StringConcatenation();
    {
      EObject _eContainer = e.eContainer();
      boolean _operator_notEquals = ObjectExtensions.operator_notEquals(_eContainer, null);
      if (_operator_notEquals) {
        _builder.append("package ");
        EObject _eContainer_1 = e.eContainer();
        QualifiedName _fullyQualifiedName = this.nameProvider.fullyQualifiedName(_eContainer_1);
        _builder.append(_fullyQualifiedName, "");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("public class ");
    String _name = e.getName();
    _builder.append(_name, "");
    _builder.append(" ");
    {
      Entity _superType = e.getSuperType();
      boolean _operator_notEquals_1 = ObjectExtensions.operator_notEquals(_superType, null);
      if (_operator_notEquals_1) {
        _builder.append("extends ");
        Entity _superType_1 = e.getSuperType();
        QualifiedName _fullyQualifiedName_1 = this.nameProvider.fullyQualifiedName(_superType_1);
        _builder.append(_fullyQualifiedName_1, "");
        _builder.append(" ");
      }
    }
    _builder.append("{");
    _builder.newLineIfNotEmpty();
    {
      EList<Feature> _features = e.getFeatures();
      for(Feature f : _features) {
        _builder.append("    ");
        StringConcatenation _compile = this.compile(f);
        _builder.append(_compile, "    ");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
  
  public StringConcatenation compile(final Feature f) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("private ");
    Type _type = f.getType();
    QualifiedName _fullyQualifiedName = this.nameProvider.fullyQualifiedName(_type);
    _builder.append(_fullyQualifiedName, "");
    _builder.append(" ");
    String _name = f.getName();
    _builder.append(_name, "");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("public ");
    Type _type_1 = f.getType();
    QualifiedName _fullyQualifiedName_1 = this.nameProvider.fullyQualifiedName(_type_1);
    _builder.append(_fullyQualifiedName_1, "");
    _builder.append(" get");
    String _name_1 = f.getName();
    String _firstUpper = StringExtensions.toFirstUpper(_name_1);
    _builder.append(_firstUpper, "");
    _builder.append("() {");
    _builder.newLineIfNotEmpty();
    _builder.append("    ");
    _builder.append("return ");
    String _name_2 = f.getName();
    _builder.append(_name_2, "    ");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("public void set");
    String _name_3 = f.getName();
    String _firstUpper_1 = StringExtensions.toFirstUpper(_name_3);
    _builder.append(_firstUpper_1, "");
    _builder.append("(");
    Type _type_2 = f.getType();
    QualifiedName _fullyQualifiedName_2 = this.nameProvider.fullyQualifiedName(_type_2);
    _builder.append(_fullyQualifiedName_2, "");
    _builder.append(" ");
    String _name_4 = f.getName();
    _builder.append(_name_4, "");
    _builder.append(") {");
    _builder.newLineIfNotEmpty();
    _builder.append("    ");
    _builder.append("this.");
    String _name_5 = f.getName();
    _builder.append(_name_5, "    ");
    _builder.append(" = ");
    String _name_6 = f.getName();
    _builder.append(_name_6, "    ");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
}